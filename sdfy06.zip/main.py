import colorama

'''
На мою думку най головнішими функціями бібліотеки colorama є:
1.just_fix_windows_console(), і 2.init()
1.just_fix_windows_console() відповідає за зв`язок з іншими бібліотеками які міняють кольори 
2.init() ініціалізує й робить автозкидання кольору
поведінки.
'''

help(colorama)